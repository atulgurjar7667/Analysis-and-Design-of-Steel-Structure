from django.apps import AppConfig


class SupportedConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'supported'
