from django.apps import AppConfig


class CompressionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'compression'
